package client;

public interface MyInterface {}


